* Title:            Package for the channel interface OVC.
* Name:             channel
* Version:          0.1
* Created:          Sun Feb 15 11:02:24 2009 
* Support:          meade@cadence.com

* Description: 

This is the channel OVC.
The channel is a basic point to point protocol implemented in
SystemVerilog, designed to work with the open source UVM library.

* Directory structure:

This package contains the following directories: 

  sv/	    - All SystemVerilog source files
  tb/       - Verification Environment examples 
  docs/     - All package documentation
            
